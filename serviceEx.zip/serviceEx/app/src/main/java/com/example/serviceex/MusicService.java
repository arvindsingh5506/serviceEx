package com.example.serviceex;


import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.IBinder;
import android.provider.Settings;

import androidx.annotation.Nullable;


public class MusicService extends Service {
MediaPlayer mp;
    @Override
    public boolean moveDatabaseFrom(Context sourceContext, String name) {
        return super.moveDatabaseFrom(sourceContext, name);
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
      mp= MediaPlayer.create(this, Settings.System.DEFAULT_RINGTONE_URI);
      mp.setLooping(true);
      mp.start();
      return START_STICKY;
    }
    @Override
    public void onDestroy(){
        mp.stop();
        super.onDestroy();
}
}
